#!/usr/bin/env python3
"""Analysis entrypoint. Reads data resources and writes results to /output."""

import pandas as pd
import os

data_path = "/data"
output_path = "/output"

print(f"Data directory contents: {os.listdir(data_path)}")

print("Analysis complete.")
